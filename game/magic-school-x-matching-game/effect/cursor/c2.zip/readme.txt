﻿=== Magic Wands Cursor Set ===

By: Geometrybrah (http://www.rw-designer.com/user/78954) gb3205@k12.sd.us

Download: http://www.rw-designer.com/cursor-set/magic-wands

Author's description:

One of my first complete cursor sets with a specific role for each! MAAAAAAAGIIIIIIC!!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.